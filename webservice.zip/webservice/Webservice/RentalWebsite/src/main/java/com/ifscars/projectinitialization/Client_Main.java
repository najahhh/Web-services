package com.ifscars.projectinitialization;

import java.rmi.Naming;  


import com.ifscars.service.IEmployee;
import com.ifscars.service.IEmployeeService;
import com.ifscars.service.IVehicle;
import com.ifscars.service.IVehicleService;

public class Client_Main {
	
	public static final String HOST="rmi://localhost:";
	
	public static void main(String[] args) {
		try{
			
			//Employees created locally 
			IEmployeeService empService = (IEmployeeService) Naming.lookup("rmi://localhost:1010/EmployeeService");
			IEmployee e1= empService.addEmployee(11, "Fenni","Hassen","helfenni","azerty");
			IEmployee e2=empService.addEmployee(22, "Fredj","Najeh", "fnajeh","azerty");
			IEmployee e3=empService.addEmployee(33, "Marnissi","Skander","smarnissi","azerty");
			IEmployee e4=empService.addEmployee(44, "Jedda","Talel","jtalel","azerty");
			IEmployee e5=empService.addEmployee(55, "Jedda","Bilel","jbilel","azerty");
			IEmployee e6=empService.addEmployee(66, "Ayachi","Hosni","ahosni","azerty");
			System.out.println(empService.getEmployeeList().size());
			//Vehicules Created through RMI Stub
			IVehicleService vService = (IVehicleService) Naming.lookup(HOST+"1099/VehiculeService");
			vService.addVehicle(123456, "Mercedes", "Class-C",0,10000);
			vService.addVehicle(223456, "Mercedes", "Class-C",0,15000);
			vService.addVehicle(323456, "Mercedes", "Class-C",0,7000);
			vService.addVehicle(423456, "Mercedes", "Class-C",0,5000);
			
			vService.addVehicle(523456, "Mercedes", "Class-C",0,4000);
			vService.addVehicle(623456, "Mercedes", "Class-C",0,2500);
			vService.addVehicle(723456, "Mercedes", "Class-C",0,12000);
			vService.addVehicle(823456, "Mercedes", "Class-C",0,8000);
			vService.addVehicle(923456, "Mercedes", "Class-C",2,4000);
			
			System.out.println("There are "+vService.getVehicles().size() +" Vehicles in total");
			IVehicle v1=vService.searchByMatricule(123456);// for sale & rental because it had been rented at least once and no one is renting it right now  
			IVehicle v2=vService.searchByMatricule(223456);// for sale & rental because it had been rented at least once and no one is renting it right now
			IVehicle v3=vService.searchByMatricule(323456);// for sale & rental because it had been rented at least once and no one is renting it right now
			IVehicle v4=vService.searchByMatricule(423456);// for sale & rental because it had been rented at least once and no one is renting it right now 
			
			IVehicle v5=vService.searchByMatricule(523456);// for rental only because it is currently rented by e6 
			IVehicle v6=vService.searchByMatricule(623456);// for rental because it hasn't been rented at all 
			IVehicle v7=vService.searchByMatricule(723456);// for rental because it hasn't been rented at all 
			IVehicle v8=vService.searchByMatricule(823456);// for rental because it hasn't been rented at all 
			IVehicle v9=vService.searchByMatricule(923456);// already sold 
			
			vService.rentVehicle(e1,v1);  
			vService.rentVehicle(e2,v2); 
			vService.rentVehicle(e3, v3); 
			vService.rentVehicle(e4, v4);
			//---------------
			vService.rentVehicle(e5, v5);
			vService.rentVehicle(e6, v5);
			vService.returnVehicle(v5, "nice car");
			//---------------
			vService.returnVehicle(v1, "nice car"); 
			vService.returnVehicle(v2, "good"); 
			vService.returnVehicle(v3, "nice car"); 
			vService.returnVehicle(v4, "good"); 
			for (int i=0;i<vService.getVehicles().size();i++) {
				System.out.println("The state of Vehicle "+(i+1)+" is: " +vService.getVehicles().get(i).getState()+" ;;; This vehicule has been rented: "+ vService.getVehicles().get(i).getCounter() +" times !");
			}
			System.out.println("How many vehicles for sale? : "+vService.getVehiclesRentedOnce().size());
			System.out.println("How many vehicles for rental? : "+vService.getVehiclesForRental().size());
			System.out.println("How many vehicles sold already? : "+vService.getVehiclesSOLD().size());
	
			
			/*System.out.println("state before rent : "+ vService.searchByMatricule(123456).getState());
			System.out.println("state v1 before rent : "+ v1.getState());
			
			vService.rentVehicle(e1, vService.searchByMatricule(123456));
			
			System.out.println("state after rent: "+ vService.searchByMatricule(123456).getState());
			System.out.println("state v1 after rent : "+ v1.getState());*/
	
			/*vService.rentVehicle(e2, vService.searchByMatricule(123456));
			vService.returnVehicle(vService.searchByMatricule(123456),"Good car");  */
			
			/*
			System.out.println("Notifications de "+e2+"=="+ e2.getNotifications());
			System.out.println("===============================================");
			
			System.out.println("state server== "+vService.getVehicles().get(0).getState());
			System.out.println("number of vehicles: "+vService.getVehicles().size());
			*/
			
			/*
			vService.getVehicles().get(0).setState(1);
			System.out.println("state here== "+v1.getState());
			System.out.println("state server== "+vService.getVehicles().get(0).getState());
			/*
			
			/*v2.rentVehicle(e1);
			v2.rentVehicle(e2);
			v2.returnVehicle("Good car");
			Thread.sleep(500);
			v2.returnVehicle("Not bad");
			Thread.sleep(500);
						
			System.out.println("Notes==" +v2.getNotes());
			System.out.println("Notifications de "+e2+"=="+ e2.getNotifications());*/
		
			/*for (int i=0;i<5;i++) {
				vService.rentVehicle(e1, v1);
				vService.rentVehicle(e2, v1);
				vService.rentVehicle(e3, v1);
				System.out.println();
				System.out.println("subscribers :" +v1.getSubscribers().size());
				vService.returnVehicle(v1,"Good car");
						//System.out.println("Employee == "+h.toString());
				System.out.println("Notifications de "+e2+"=="+ e2.getNotifications()); //najeh will get notified
				Thread.sleep(500);
				vService.returnVehicle(v1,"Not bad");
				System.out.println("Notifications de "+e3+"=="+ e3.getNotifications()); //skander will get notified
				Thread.sleep(500);
				vService.returnVehicle(v1,"Okay"); // no one will get notified since Queue is now empty 
				Thread.sleep(500);
			}*/
			
			
		}catch(Exception e){e.printStackTrace();}
	}

}

