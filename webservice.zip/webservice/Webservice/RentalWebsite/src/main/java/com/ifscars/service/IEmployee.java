package com.ifscars.service;

import java.rmi.Remote;    
import java.rmi.RemoteException;
import java.util.List;

public interface IEmployee extends Remote{
	public void notifyChange(int oldState,int newState,String v) throws RemoteException;
	public int getId() throws RemoteException;
	public String getNom() throws RemoteException;
	public String getPrenom() throws RemoteException;
	public List<String> getNotifications() throws RemoteException;
	public String getLogin() throws RemoteException;
	public String getMdp() throws RemoteException;
	public String getFullName() throws RemoteException;
}
