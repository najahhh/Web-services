package com.ifscars.test;

import java.rmi.Naming; 
import java.rmi.RemoteException;

import com.ifscars.service.IVehicle;
import com.ifscars.service.IVehicleService;


public class test {
	
	public static final String HOST="rmi://localhost:";
	public static void main(String[] args) throws RemoteException {
		// TODO Auto-generated method stub
		/*try {
		IVehicleService vService = (IVehicleService) Naming.lookup(HOST+"1099/VehiculeService");
		vService.searchByMatricule(123456).setState(1);
		}catch(Exception e) {
			System.err.println(e);
		}*/
		//		EmployeeService eService = EmployeeService.GetInstance();
//		System.out.println(eService.getEmployeeList());
//		System.out.println(eService.getEmployeeByLogins("helfenni","azerty"));
		
	}
}
