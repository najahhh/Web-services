package com.ifscars.managedbean;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.view.ViewScoped;

import com.ifscars.service.IEmployee;
import com.ifscars.service.impl.ProductRentalService;
import com.ifscars.entities.Product;


@ManagedBean(name="ProductRentalController")
@SessionScoped
public class ProductRentalController  {
	
	ProductRentalService productRentalService;
	String lastName;
	String firstName;
	String login;
	String mdp;
	/*String profile;
	List<String> data;
	Map<String,List<String>> profiles = new HashMap<String, List<String>>();*/
	
	
	String note;//="Great car, still in perfect shape !";

	
	
	public ProductRentalController() throws RemoteException {
		this.productRentalService = new ProductRentalService();
	}
	
	
	// methods 
	
	@PostConstruct
    public void init() {
		try {
			lastName=productRentalService.getEmployeeList().get(1).getNom();
			firstName=productRentalService.getEmployeeList().get(1).getPrenom();
			login=productRentalService.getEmployeeList().get(1).getLogin();
			mdp=productRentalService.getEmployeeList().get(1).getMdp();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
    
    
    /*
        try {
			for (IEmployee x:this.productRentalService.getEmployeeList()){
				List<String> profileData = new ArrayList<>();
				profileData.add(x.getNom());
				profileData.add(x.getPrenom());
				profileData.add(x.getLogin());
				profileData.add(x.getMdp());
				profiles.put(x.getFullName(),profileData);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
        
	}*/
	
	public List<Product> getCatalogueForRentalController() throws RemoteException {
		return this.productRentalService.getCatalogueForRental();
	}
	
	
	
	
	public void rentVehicleController(String login,String mdp,int matricule) throws RemoteException {
		this.productRentalService.rentVehicle(login, mdp, matricule);
	}
	
	
	
	
	public void returnVehicleController(int matricule,String note) throws RemoteException {
		this.productRentalService.returnVehicle(matricule, note);
	}
	
	
	/*public void onProfileChange() {
        if(profile !=null && !profile.equals("")) {
        	data = profiles.get(profile);
        	lastName = data.get(0);
        	firstName = data.get(1);
        	login = data.get(2);
        	mdp=data.get(3);
        }
 
        else {
        	data = new ArrayList<String>();
        }
        	
    }*/
	
	
	public String getEmployeeByID(int id) throws RemoteException {
		return this.productRentalService.getEmployeeByID(id);
	}
	
	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getMdp() {
		return mdp;
	}

	public void setMdp(String mdp) {
		this.mdp = mdp;
	}

	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	/*public String getProfile() {
		return profile;
	}


	public void setProfile(String profile) {
		this.profile = profile;
	}


	public List<String> getData() {
		return data;
	}


	public void setData(List<String> data) {
		this.data = data;
	}


	public Map<String, List<String>> getProfiles() {
		return profiles;
	}


	public void setProfiles(Map<String, List<String>> profiles) {
		this.profiles = profiles;
	}*/
	
}
