package com.ifscars.entities;
 

import java.rmi.RemoteException;

import java.util.List;
import java.util.Queue;
import com.ifscars.service.IEmployee;

 
public class Product {

	private int matricule;
	private String brand; 
	private String model;
	private int state; // 0==not rented ; 1==rented ; 2==sold
	private double price;
	private List<String> notes;
	private Queue<IEmployee> subscribers;
	private int counter;
	private int rentedTo_id;
	private String rentedTo_fullName;
	
	public Product() throws RemoteException {
	}

	
	
	public Product(int matricule, String brand, String model, int state, double price, List<String> notes,
			Queue<IEmployee> subscribers, int counter, int rentedTo_id,String rentedTo_fullName) {
		this.matricule = matricule;
		this.brand = brand;
		this.model = model;
		this.state = state;
		this.price = price;
		this.notes = notes;
		this.subscribers = subscribers;
		this.counter = counter;
		this.rentedTo_id = rentedTo_id;
		this.rentedTo_fullName=rentedTo_fullName;
	}



	public Queue<IEmployee> getSubscribers() {
		return subscribers;
	}

	public void setSubscribers(Queue<IEmployee> subscribers) {
		this.subscribers = subscribers;
	}

	public int getMatricule() {
		return matricule;
	}

	public void setMatricule(int matricule) {
		this.matricule = matricule;
	}



	public String getBrand() {
		return brand;
	}



	public void setBrand(String brand) {
		this.brand = brand;
	}



	public String getModel() {
		return model;
	}



	public void setModel(String model) {
		this.model = model;
	}



	public int getState() {
		return state;
	}



	public void setState(int state) {
		this.state = state;
	}



	public double getPrice() {
		return price;
	}



	public void setPrice(double price) {
		this.price = price;
	}



	public List<String> getNotes() {
		return notes;
	}



	public void setNotes(List<String> notes) {
		this.notes = notes;
	}






	public int getCounter() {
		return counter;
	}



	public void setCounter(int counter) {
		this.counter = counter;
	}



	public int getRentedTo_id() {
		return rentedTo_id;
	}



	public void setRentedTo_id(int rentedTo_id) {
		this.rentedTo_id = rentedTo_id;
	}



	public String getRentedTo_fullName() {
		return rentedTo_fullName;
	}



	public void setRentedTo_fullName(String rentedTo_fullName) {
		this.rentedTo_fullName = rentedTo_fullName;
	}
	
}
