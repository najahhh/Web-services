package com.ifscars.service.impl;

import java.rmi.Naming;   
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import com.ifscars.entities.Product;
import com.ifscars.service.IVehicle;
import com.ifscars.service.IVehicleService;
import com.ifscars.service.IEmployee;
import com.ifscars.service.IEmployeeService;

public class ProductRentalService {
	private IVehicleService vService;
	private List<Product> pList;
	private IEmployeeService empService;
	
	public ProductRentalService() throws RemoteException {
		try {
			vService = (IVehicleService) Naming.lookup("rmi://localhost:1099/VehiculeService");
			empService=(IEmployeeService) Naming.lookup("rmi://localhost:1010/EmployeeService");
			pList = new ArrayList<Product>() ;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public List<Product> getCatalogueForRental() throws RemoteException{
		pList.clear();
		for (IVehicle x:vService.getVehiclesForRental()) {
				pList.add(new Product(x.getMatricule(),x.getBrand(),x.getModel(),x.getState(),Math.round(x.getPrice()/150),x.getNotes(),x.getSubscribers(),x.getCounter(),x.getRentedTo_id(),x.getRentedTo_fullName()));
			}
		return(pList);
	}
	
	public void rentVehicle(String login,String mdp,int matricule) throws RemoteException{
		IEmployee e = empService.getEmployeeByLogins(login, mdp);
		IVehicle v = vService.searchByMatricule(matricule);
		vService.rentVehicle(e, v);
		System.out.println("Vehicle: "+v.getMatricule()+" has been rented to: "+e.getFullName());
	}
	
	public void returnVehicle(int matricule,String note) throws RemoteException{
		IVehicle v = vService.searchByMatricule(matricule);
		vService.returnVehicle(v, note);
		System.out.println("Vehicle: "+ v.getMatricule() +" has been returned");
	}

	public String getEmployeeByID(int id) throws RemoteException {
		if(id!=0) {
			return empService.getEmployeeByID(id).getNom()+" "+empService.getEmployeeByID(id).getPrenom();
		}
		return "This vehicle is available !";
	}
	
	public List<IEmployee> getEmployeeList() throws RemoteException {
		return empService.getEmployeeList();
	}
}
