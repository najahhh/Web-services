package com.ifscars.managedbean;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.model.SelectItem;
import javax.xml.rpc.ServiceException;

import com.ifscars.entities.Product;
import com.ifscars.service.impl.ProductSaleService;

@ManagedBean(name="ProductController")
@SessionScoped
public class ProductController  {

	
	private long rib;
	private long iban;
	private int cvc;
	private String country;
	private String firstName;
	private String lastName;
	private String adress;
	private String city;
	
	public final List<String> COUNTRIES = getCountriesINITIALIZATION();
	public final List<String> COUNTRIESISO = getCountriesISOINITIALIZATION();
	public final HashMap<String,String> HMAP = HmapINITIALIZATION();
	
	ProductSaleService productService;
	
	public ProductController() throws RemoteException {
		super();
		this.productService = new ProductSaleService();
	}
	

	public List<String> getCountriesINITIALIZATION(){
		List<String> countries = new ArrayList<>();
    	Arrays.stream(Locale.getISOCountries()).forEach(c->{
    		Locale obj = new Locale("", c);
    		countries.add(obj.getDisplayCountry());
    	});
		return countries;
	}
	
	public List<String> getCountriesISOINITIALIZATION() {
		List<String> countries = new ArrayList<>();
    	Arrays.stream(Locale.getISOCountries()).forEach(c->{
    		Locale obj = new Locale("", c);
    		countries.add(obj.getCountry());
    	});
		return countries;
	}

	public HashMap<String, String> HmapINITIALIZATION() {
		HashMap<String,String> hmap = new HashMap<>();
		for(int i=0;i<COUNTRIES.size();i++) {
			hmap.put(COUNTRIES.get(i),COUNTRIESISO.get(i));
		}
		return hmap;
	}
	
	
	public double getPriceInUserCurrency(String country,double price) throws RemoteException, ServiceException {
		return this.productService.getPriceInUserCurrency(country, price);
	}
	
	
	public List<Product> getProducts() throws RemoteException {
		return this.productService.getCatalogueForSale();
	}
	
	public List<Product> getBasket() throws RemoteException {
		return this.productService.getBasket();
	}
	
	public void addToBasketController(Product product) throws RemoteException {
		this.productService.addToBasket(product);
	}
	
	public void removeFromBasketController(Product p) throws RemoteException {
		this.productService.removeFromBasket(p);
	}
	
	public void emptyBasketController() throws RemoteException{
		this.productService.emptyBasket();
	}
	
	public double getBasketTotalAmount() throws RemoteException{
		return(this.productService.getBasketTotalAmount());
	}
	
	public double getCustomerCurrentBalance(long rib,long iban,int cvc) throws RemoteException{
		return(this.productService.getCustomerCurrentBalance(rib,iban,cvc));
	}
	
	public void purchase(List<Product> liste,double totalAmnt,long rib,long iban,int cvc) throws RemoteException, ServiceException{
		this.productService.purchase(liste,totalAmnt,rib,iban,cvc);
		
	}
	

	public long getRib() {
		return rib;
	}


	public void setRib(long rib) {
		this.rib = rib;
	}


	public long getIban() {
		return iban;
	}


	public void setIban(long iban) {
		this.iban = iban;
	}


	public int getCvc() {
		return cvc;
	}


	public void setCvc(int cvc) {
		this.cvc = cvc;
	}
	
	/*public List<String> getCountries() {
		return COUNTRIES;
	}

	public List<String> getCountriesiso() {
		return COUNTRIESISO;
	}*/

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public List<String> getCOUNTRIES() {
		return COUNTRIES;
	}

	public List<String> getCOUNTRIESISO() {
		return COUNTRIESISO;
	}

	public HashMap<String, String> getHMAP() {
		return HMAP;
	}
	
	
}
