package com.ifscars.service.impl;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.rpc.ServiceException;

import org.oorsprong.www.websamples_countryinfo.CountryInfoServiceLocator;
import org.oorsprong.www.websamples_countryinfo.CountryInfoServiceSoapType;

import com.bank.bankservice.BankService;
import com.bank.bankservice.BankServiceServiceLocator;
import com.currencysystem.webservices.currencyserver.CurncsrvReturnRate;
import com.currencysystem.webservices.currencyserver.CurrencyServerLocator;
import com.currencysystem.webservices.currencyserver.CurrencyServerSoap;
import com.ifscars.entities.Product;
import com.ifscars.service.IVehicle;
import com.ifscars.service.IVehicleService;
import com.lavasoft.GeoIPServiceLocator;
import com.lavasoft.GeoIPServiceSoap;

public class ProductSaleService {

	private IVehicleService vService;
	private List<Product> basket;
	private List<Product> pList;

	public ProductSaleService() throws RemoteException {
		try {
			vService = (IVehicleService) Naming.lookup("rmi://localhost:1099/VehiculeService");
			pList = new ArrayList<>();
			basket = new ArrayList<>();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<Product> getCatalogueForSale() throws RemoteException {
		pList.clear();
		for (IVehicle x : vService.getVehiclesRentedOnce()) {
			pList.add(new Product(x.getMatricule(), x.getBrand(), x.getModel(), x.getState(), x.getPrice(),
					x.getCounter()));
		}
		return (pList);
	}

	public void addToBasket(Product p) throws RemoteException {
		boolean var = true;
		for (Product x : basket) {
			if (x.getMatricule() == p.getMatricule()) {
				var = false;
			}
		}
		if (var) {
			basket.add(p);
			System.out.println("I'm adding the Vehicle with matricule: " + p.getMatricule() + " to basket!");
		}
	}

	public void removeFromBasket(Product p) throws RemoteException {
		System.out.println("Product " + p.toString() + " is getting deleted from basket!");
		basket.remove(p);
	}

	public void emptyBasket() throws RemoteException {
		basket.clear();
	}

	public double getBasketTotalAmount() throws RemoteException {
		double Total = 0;
		for (Product p : basket) {
			Total += p.getPrice();
		}
		return Total;
	}

	public void purchase(List<Product> listeAchat, double totalAmnt, long rib, long iban, int cvc)
			throws RemoteException, ServiceException {
		// Call to bank in order to verify if the transaction is possible or not
		BankService bank;
		int result;
		
		bank = new BankServiceServiceLocator().getBankService();
		result = bank.validatePurchase(rib, iban, cvc, totalAmnt);
		if (result==1) { // if client has enough credit change state of all vehicules in basket to sold
			for (Product x : listeAchat) {
				IVehicle v =vService.searchByMatricule(x.getMatricule());
				vService.buyVehicle(v); //sets state to 2 meaning sold
				System.out.println("Purchase done,The customer balance after transaction is: " + bank.getCustomerBalance(rib, iban, cvc));
			}
			this.emptyBasket();
		}
		else if(result==0) {
			System.out.println("Not enough credit !");
		}
		else {System.out.println("Verify Credentials !");
		}
				
	}

	// Just for verification purposes
	public double getCustomerCurrentBalance(long rib, long iban, int cvc) throws RemoteException {
		BankService bank;
		try {
			bank = new BankServiceServiceLocator().getBankService();
			return (bank.getCustomerBalance(rib, iban, cvc));
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		return 0;
	}

	// ************************WEB SERVICE FUNCTIONS*****************************//

	public double getPriceInUserCurrency(String country, double price) throws ServiceException, RemoteException { 
		CountryInfoServiceSoapType countryTocur;
		
		countryTocur = new CountryInfoServiceLocator().getCountryInfoServiceSoap();
	
		// exp: get "FR" from "France"
		String countryISO=countryTocur.countryISOCode(country);
		// exp:get "EUR" from "FR"
		String currencyISO = countryTocur.countryCurrency(countryISO).getSISOCode();
		// exp:get price in "EUR"
		return (double) (CurrencyConverter(currencyISO, price));
	}

	public static Object CurrencyConverter(String toCur, double amnt) throws RemoteException {
		CurrencyServerSoap currencySystem;
		try {
			currencySystem = new CurrencyServerLocator().getCurrencyServerSoap();
			return (currencySystem.convert("", "EUR", toCur, amnt, false, "",
					CurncsrvReturnRate.curncsrvReturnRateNumber, "", ""));
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		return null;
	}

	public String getCountryISOFromIP(String ip) throws RemoteException {
		GeoIPServiceSoap ipSystem;
		try {
			ipSystem = new GeoIPServiceLocator().getGeoIPServiceSoap();
			return ipSystem.getIpLocation(ip).split(">")[2].split("<")[0];
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		return ("Can't access CountryISOFromIP Web Service ! ");
	}

	// GETTERS AND SERTTERS
	public IVehicleService getvService() {
		return vService;
	}

	public void setvService(IVehicleService vService) {
		this.vService = vService;
	}

	public List<Product> getBasket() {
		return basket;
	}

	public void setBasket(List<Product> basket) {
		this.basket = basket;
	}

	public List<Product> getpList() {
		return pList;
	}

	public void setpList(List<Product> pList) {
		this.pList = pList;
	}

}