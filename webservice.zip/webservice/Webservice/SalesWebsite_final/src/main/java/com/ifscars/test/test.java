package com.ifscars.test;

import java.rmi.RemoteException;   
import java.util.List;

import javax.xml.rpc.ServiceException;

import org.oorsprong.www.websamples_countryinfo.CountryInfoServiceLocator;
import org.oorsprong.www.websamples_countryinfo.CountryInfoServiceSoapType;

import com.bank.bankservice.BankService;
import com.bank.bankservice.BankServiceServiceLocator;
import com.currencysystem.webservices.currencyserver.CurncsrvReturnRate;
import com.currencysystem.webservices.currencyserver.CurrencyServerLocator;
import com.currencysystem.webservices.currencyserver.CurrencyServerSoap;
import com.ifscars.entities.Product;
import com.ifscars.managedbean.ProductController;
import com.ifscars.service.impl.ProductSaleService;
import com.lavasoft.GeoIPServiceLocator;
import com.lavasoft.GeoIPServiceSoap;



public class test {

	private static List<Product> pList;
	static ProductSaleService serviceProduit;

	public static void main(String[] args) throws RemoteException {
		/*try {
			serviceProduit = new ProductSaleService();
		 	pList=serviceProduit.getCatalogueForSale();
			//serviceProduit.addToBasket(pList.);
			
			System.out.println(serviceProduit.CurrencyConverter("USD",1));
			
			
			
		} catch (RemoteException e) {
			e.printStackTrace();
		}*/
		
		//***********CURRENCY CONVERTER WEB SERVICE******************// 
		CurrencyServerSoap currencySystem;
		try {
			currencySystem = new CurrencyServerLocator().getCurrencyServerSoap();
			System.out.println("100EUR corresponds to "+ currencySystem.convert("", "EUR","USD",100, false, "",
					CurncsrvReturnRate.curncsrvReturnRateNumber, "", "")+"USD" );
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		
		//COUNTRY ISO FROM COUNTRY NAME
		CountryInfoServiceSoapType countryTocur;
		try {
			countryTocur =  new CountryInfoServiceLocator().getCountryInfoServiceSoap();
			
			System.out.println("ISO of 'France' is: " + countryTocur.countryISOCode("France"));
			
		} catch (ServiceException e) {
			e.printStackTrace();
			
		}
		//**********WEB SERVICE GIVES CURRENCY CODE FROM COUNTRY ISO*********/
		CountryInfoServiceSoapType countryTocur2;
		try {
			countryTocur2 =  new CountryInfoServiceLocator().getCountryInfoServiceSoap();
			
			System.out.println("Currency of 'FR' is: " + countryTocur2.countryCurrency("FR").getSISOCode());
			
		} catch (ServiceException e) {
			e.printStackTrace();
			
		}
		
		
		//test
		/*ProductController pc= new ProductController();
			for(String x:pc.COUNTRIES) {
				try {
					System.out.println(pc.getPriceInUserCurrency(x,100));
				} catch (RemoteException | ServiceException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		*/
		
		
		
		
		//**********WEB SERVICE GEOLOCALISATION GIVES COUNTRY ISO FROM IP**********//
			/*	GeoIPServiceSoap ipSystem;
				try {
					ipSystem = new GeoIPServiceLocator().getGeoIPServiceSoap();
					String ip ="91.171.224.87";
					String country = ipSystem.getIpLocation(ip).split(">")[2].split("<")[0];
					System.out.println("your country iso is : "+country);
				} catch (ServiceException e) {
					e.printStackTrace();
				}
		*/
		//*****************Gets client IP adress**************/
		/*HttpServletRequest request = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
		String ipAddress = request.getHeader("X-FORWARDED-FOR");
		if (ipAddress == null) {
		    ipAddress = request.getRemoteAddr();
		}
		System.out.println("ipAddress:" + ipAddress);*/
		
		//**********BANK WEB SERVICE*********/
		/*BankService bank ;
		try {
			bank= new BankServiceServiceLocator().getBankService();
			//System.out.println("For verification purposes, the balance before transaction is: " +bank.getAccListWS()[0]);
			
			System.out.println(bank.getCustomerBalance(123456, 456789, 123));
			System.out.println(bank.validatePurchase(123456, 456789, 123, 10));
			System.out.println(bank.getCustomerBalance(123456, 456789, 123));
			//System.out.println("For verification purposes, the balance after transaction is: " +bank.getAccListWS()[0]);
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		*/
		/***********************/
	
		
		
		
		
		
	
		
		
		
		
		
	}
}
