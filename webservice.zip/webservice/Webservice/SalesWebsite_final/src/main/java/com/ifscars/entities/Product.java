package com.ifscars.entities;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.List;

public class Product implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int matricule;
	private String brand; 
	private String model;
	private int state; // 0==not rented ; 1==rented ; 2==sold
	private double price;
	private List<String> notes;
	private int counter;
	private int rentedTo_id;
	
	public Product() throws RemoteException {
	}

	public Product(int matricule, String brand, String model, int state, double price, int counter) {
		super();
		this.matricule = matricule;
		this.brand = brand;
		this.model = model;
		this.state = state;
		this.price = price;
	}

	public int getMatricule() {
		return matricule;
	}

	public void setMatricule(int matricule) {
		this.matricule = matricule;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public List<String> getNotes() {
		return notes;
	}

	public void setNotes(List<String> notes) {
		this.notes = notes;
	}

	public int getCounter() {
		return counter;
	}

	public void setCounter(int counter) {
		this.counter = counter;
	}

	public int getRentedTo_id() {
		return rentedTo_id;
	}

	public void setRentedTo_id(int rentedTo_id) {
		this.rentedTo_id = rentedTo_id;
	}

	@Override
	public String toString() {
		return "Product [matricule=" + matricule + ", brand=" + brand + ", model=" + model + ", state=" + state
				+ ", price=" + price + ", notes=" + notes + ", counter=" + counter + ", rentedTo_id=" + rentedTo_id
				+ "]";
	}
	
	
	
	
}
