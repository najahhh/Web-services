package com.ifscars.test;

import java.rmi.Naming; 
import java.rmi.registry.LocateRegistry;

import com.ifscars.service.IVehicleService;
import com.ifscars.service.impl.VehicleService;

public class Server_Main {
	public static void main(String[] args) {
		try {
			LocateRegistry.createRegistry(1099);
			IVehicleService vService = VehicleService.GetInstance();
			Naming.rebind("rmi://localhost:1099/VehiculeService",vService);
			System.out.println("First RMI Server launched...");
		}catch(Exception e){
			System.out.println("Trouble"+e);
		}
	}
}
