package com.ifscars.service.impl;

import java.rmi.RemoteException;     
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

import com.ifscars.entities.Vehicle;
import com.ifscars.service.IEmployee;
import com.ifscars.service.IVehicle;
import com.ifscars.service.IVehicleService;


public class VehicleService extends UnicastRemoteObject implements IVehicleService {
	
	private  List<Vehicle> entrepot;
		

	
	 // private constructor restricted to this class itself 
	private VehicleService() throws RemoteException
    {
		entrepot = new ArrayList<Vehicle>();
    }
     
    private static VehicleService single_instance=null; 
    
  
    // static method to create instance of VehicleService class 
    public static VehicleService GetInstance() throws RemoteException
    { 
        // To ensure only one instance is created 
        if (single_instance == null) 
        { 
            single_instance = new VehicleService(); 
        } 
        return single_instance; 
    }
	
	
    //METHODS

	public void addVehicle(int mat, String brand, String model, int state, int price) throws RemoteException {
		Vehicle v = new Vehicle(mat,brand,model,state,price);
		entrepot.add(v);
	}

	
	public void removeVehicleByMatricule(int mat) throws RemoteException {
		for (Vehicle x:entrepot) {
			if (x.getMatricule()==mat) {
				entrepot.remove(x);
			}
		}
	}

	public List<IVehicle> getVehicles() throws RemoteException {
		List vList=new ArrayList<Vehicle>();
		for (Vehicle x:entrepot) {
			vList.add(x);
		}
		return(vList);
	}
	
	public List<IVehicle> getVehiclesForRental() throws RemoteException{
		List vList=new ArrayList<Vehicle>();
		for (Vehicle x:entrepot) {
			if (x.getState()!=2) {
				vList.add(x);
			}
		}
		return(vList);
	}
	
	public List<IVehicle> getVehiclesRentedOnce() throws RemoteException { // these are the vehicules FOR SALE
		List vList=new ArrayList<Vehicle>();
		for (Vehicle x:entrepot) {
			if( (x.getState()==0) & (x.getSubscribers().isEmpty()) ){ // vehicles that aren't currently being rented and that have no employees in waiting list
				if(x.getCounter()>=1) { // and have been rented at least once in the past
					vList.add(x);
				}
			}
		}
		return vList;
	}
	
	public List<IVehicle> getVehiclesSOLD() throws RemoteException{
		List vList=new ArrayList<Vehicle>();
		for (Vehicle x:entrepot) {
			if (x.getState()==2) {
				vList.add(x);
			}
		}
		return(vList);
	}
	
	

	public synchronized void rentVehicle(IEmployee e, IVehicle v) throws RemoteException {
		if (v.getRentedTo_id()!=e.getId()){ //verify that it's not the same employee trying to rent the car again
			if (v.getState()==1){ //if the car is rented --> add employee to subscriber list
				Queue<IEmployee>subQueue = v.getSubscribers(); 
				subQueue.add(e);
				v.setSubscribers(subQueue);
				}	
			else if(v.getState()==0){ //change state,change rentedTo,inc counter
				v.setState(1);
				v.setRentedTo_id(e.getId());
				v.setRentedTo_fullName(e.getFullName());
				v.setCounter(v.getCounter()+1);
			}
		}
	}
		
	public synchronized void returnVehicle(IVehicle v, String note) throws RemoteException {
		//update rentedTo_id,notes and state
		v.setRentedTo_fullName(null);
		v.setRentedTo_id(0);
		List<String> newNotes=v.getNotes(); newNotes.add(note); v.setNotes(newNotes);
		int oldState=v.getState(); //saving record for notification
		v.setState(0);
		
		if (v.getSubscribers().size()>0){
			IEmployee head=v.getSubscribers().peek();
			//notifyHead 
			head.notifyChange(oldState,v.getState(),searchByMatricule(v.getMatricule()).toString()); 
			rentVehicle(head,v); //rent the vehicule to the employee
			//pop the employee from Q
			Queue<IEmployee>subQueue = v.getSubscribers(); 
			subQueue.poll();
			v.setSubscribers(subQueue);
						
		}
	
	}
	
	public synchronized void buyVehicle(IVehicle v) throws RemoteException {
		//set state of vehicle to 2
		v.setState(2);
	}
		

	public List<IVehicle> searchByBrand(String brand) throws RemoteException {
		List vList=new ArrayList<Vehicle>();
		for (Vehicle x:entrepot) {
			if (x.getBrand().equals(brand) ){
				vList.add(x);
			}
		}
		return(vList);
	}

	public List<IVehicle> searchByModel(String model) throws RemoteException {
		List vList=new ArrayList<Vehicle>();
		for (Vehicle x:entrepot) {
			if (x.getModel().equals(model) ){
				vList.add(x);
			}
		}
		return(vList);
	}

	public IVehicle searchByMatricule(int matricule) throws RemoteException {
		for (Vehicle x:entrepot) {
			if (x.getMatricule()==matricule ){
				return(x);
			}
		}
		return(null);
	}


}
