package com.ifscars.entities;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import com.ifscars.service.IVehicle;
import com.ifscars.service.IEmployee;

public class Vehicle extends UnicastRemoteObject implements IVehicle {
	private int matricule;
	private String brand; 
	private String model;
	private int state; // 0==not rented ; 1==rented ; 2==sold
	private double price;
	private List<String> notes;
	private Queue<IEmployee> subscribers;
	private int counter;
	private int rentedTo_id;
	private String rentedTo_fullName;
	
	
	public Vehicle() throws RemoteException {
	}
	
	public Vehicle(int matricule, String brand, String model, int state, int price) throws RemoteException {
		this.matricule = matricule;
		this.brand = brand;
		this.model = model;
		this.state = state;
		this.price = price;
		notes=new ArrayList<String>();
		subscribers=new LinkedList<IEmployee>();
	}
	
	@Override
	public String toString() {
		return "Vehicle [matricule=" + matricule + ", brand=" + brand + ", model=" + model + ", state=" + state
				+ ", price=" + price + "]";
	}

	//GETTERS AND SETTERS
	public int getMatricule() throws RemoteException {
		return matricule;
	}
	public void setMatricule(int matricule) throws RemoteException {
		this.matricule = matricule;
	}
	public String getBrand() throws RemoteException {
		return brand;
	}
	public void setBrand(String brand) throws RemoteException {
		this.brand = brand;
	}
	public String getModel() throws RemoteException {
		return model;
	}
	public void setModel(String model) throws RemoteException {
		this.model = model;
	}
	public int getState() throws RemoteException {
		return state;
	}
	public void setState(int state) throws RemoteException {
		this.state = state;
	}
	public double getPrice() throws RemoteException {
		return price;
	}
	public void setPrice(double price) throws RemoteException {
		this.price = price;
	}
	
	public List<String> getNotes() throws RemoteException{
		return notes;
	}
	
	public void setNotes(List<String> notes) throws RemoteException{
		this.notes = notes;
	}
	public Queue<IEmployee> getSubscribers() throws RemoteException {
		return subscribers;
	}
	public void setSubscribers(Queue<IEmployee> subscribers) throws RemoteException {
		this.subscribers = subscribers;
	}
	public int getCounter() throws RemoteException {
		return counter;
	}
	
	public void setCounter(int counter) throws RemoteException {
		this.counter = counter;
	}
	public int getRentedTo_id() throws RemoteException {
		return rentedTo_id;
	}
	public void setRentedTo_id(int rentedTo_id) throws RemoteException {
		this.rentedTo_id = rentedTo_id;
	}

	public String getRentedTo_fullName() throws RemoteException{
		return rentedTo_fullName;
	}

	public void setRentedTo_fullName(String rentedTo_fullName) throws RemoteException{
		this.rentedTo_fullName = rentedTo_fullName;
	}

	
	
	
	
}
