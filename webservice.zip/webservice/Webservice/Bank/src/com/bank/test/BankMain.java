package com.bank.test;

import com.bank.bankservice.BankCrudService;
import com.bank.bankservice.BankService;

public class BankMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankCrudService crudS = BankCrudService.getInstance();
		BankService bankS = new BankService();
		System.out.println(crudS.getAccounts().toString());
		//System.out.println(bankS.getAccListWS()[0]);
		System.out.println(bankS.validatePurchase(123456, 456789, 123, 50));
		//System.out.println(bankS.getAccListWS()[0]);
		System.out.println(crudS.getAccounts().toString());

		BankCrudService crudS2 = BankCrudService.getInstance();
		System.out.println(crudS2.getAccounts().toString());
		
	//	System.out.println(bankS.getAccListWS().toString());
	}
	
}
