package com.bank.bankservice;


import java.util.List;

import javax.xml.rpc.ServiceException;

import com.currencysystem.webservices.currencyserver.CurncsrvReturnRate;
import com.currencysystem.webservices.currencyserver.CurrencyServerLocator;
import com.currencysystem.webservices.currencyserver.CurrencyServerSoap;


public class BankService {
	BankCrudService crudS = BankCrudService.getInstance();
	private static List<Account> accListWS; 
	
	public BankService() {
	
		accListWS=crudS.getAccounts();
	}
	
	public int validatePurchase(long rib,long iban,int cvc, double amount) {
		CurrencyServerSoap currencySystem;
		double amountConverted=0;
		String clientCurrency;
		try {
			currencySystem = new CurrencyServerLocator().getCurrencyServerSoap();
			clientCurrency =crudS.searchAccountBySecure(rib, iban, cvc).getCurrencyISO();
			amountConverted = (double) currencySystem.convert("", "EUR", clientCurrency ,amount, false, "",CurncsrvReturnRate.curncsrvReturnRateNumber, "", "");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(Account x:accListWS) {
			if( (x.getIban()==iban) & (x.getRib()==(rib)) & (x.getCvc()==cvc) ) {
				if(x.getBalance()>=amountConverted) {
					x.setBalance(x.getBalance()-amountConverted);
					return(1); // client has enough balance
				}
				else {
					return (0); //client doesn't have enough balance
				}
			}
		}
		return(2); //credentials are wrong
	}

	//only added this for verification purposes  
	public double getCustomerBalance(long rib,long iban,int cvc) {
		return (crudS.searchAccountBySecure(rib, iban, cvc).getBalance());
	}
	
	public String getCustomerBalanceToString(long rib,long iban,int cvc) {
		return (crudS.searchAccountBySecure(rib, iban, cvc).getBalance() +" "+crudS.searchAccountBySecure(rib, iban, cvc).getCurrencyISO());
	}

}
