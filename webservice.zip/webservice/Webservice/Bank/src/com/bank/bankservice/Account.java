package com.bank.bankservice;

import java.io.Serializable;

public class Account implements Serializable  {
	private long rib; 
	private long iban;
	private int cvc;
	private String firstName;
	private String lastName; 
	private String country;
	private double balance;
	private String currencyISO; 
	
	
	public Account() {
		super();
	}
	
	public Account(long rib, long iban,int cvc, String firstName, String lastName, String country, double balance,String currencyiso) {
		super();
		this.rib = rib;
		this.iban = iban;
		this.cvc = cvc;
		this.firstName = firstName;
		this.lastName = lastName;
		this.country = country;
		this.balance = balance;
		this.currencyISO = currencyiso;
		
	}

	public long getRib() {
		return rib;
	}

	public void setRib(long rib) {
		this.rib = rib;
	}

	public long getIban() {
		return iban;
	}

	public void setIban(long iban) {
		this.iban = iban;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getCvc() {
		return cvc;
	}

	public void setCvc(int cvc) {
		this.cvc = cvc;
	}

	@Override
	public String toString() {
		return "Account [rib=" + rib + ", iban=" + iban + ", cvc=" + cvc + ", firstName=" + firstName + ", lastName="
				+ lastName + ", country=" + country + ", balance=" + balance + "]";
	}

	public String getCurrencyISO() {
		return currencyISO;
	}

	public void setCurrencyISO(String currencyISO) {
		this.currencyISO = currencyISO;
	}
	
}

