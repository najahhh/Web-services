package com.bank.bankservice;

import java.util.ArrayList; 
import java.util.List;

public class BankCrudService { 
	
	private List<Account> accList;
	
	private BankCrudService() {
		
		accList= new ArrayList<Account>();
		
		this.addAccount(123456, 456789, 123, "Hassen", "Fenni","Tunisia",1000000,"TND");
		this.addAccount(123457, 456788, 123, "Hassen", "Fenni","Ecuador",1000000,"USD");
		this.addAccount(123458, 456787, 123, "Hassen", "Fenni","Algeria",1000000,"DZD");
		this.addAccount(123459, 456786, 123, "Hassen", "Fenni","Brazil",1000000,"BRL");
		this.addAccount(123469, 456796, 123, "Hassen", "Fenni","Ukraine",1000000,"UAH");
	}
	
	private static class SingletonHolder{       
        /** Instance unique non pr�initialis�e */
        private final static BankCrudService  instance = new BankCrudService();
    }
	
	public static BankCrudService getInstance(){
        return SingletonHolder.instance;
    }
	
	////CRUD
	public void addAccount(long rib, long iban,int cvc, String firstName, String lastName, String country, double balance,String currencyiso) {
		Account newAcc = new Account(rib,iban,cvc,firstName,lastName,country,balance,currencyiso);
		accList.add(newAcc);
	}
	
	public void removeAccount(long rib, long iban,int cvc) {
		accList.remove(searchAccountBySecure(rib,iban,cvc));
	}
	
	public List<Account> getAccounts() {
		return this.accList;
	}
	
	public Account searchAccountBySecure(long rib,long iban,int cvc) {
		for (Account x:accList) {
			if((x.getIban()==iban) & (x.getRib()==rib) & (x.getCvc()==cvc)) {
				return(x);
			}
		}
		return null; 
	}
	
	
	
	
	
}
