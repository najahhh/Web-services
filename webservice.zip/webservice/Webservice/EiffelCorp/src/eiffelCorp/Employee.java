package eiffelCorp;

import java.rmi.RemoteException;  
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

import com.ifscars.service.IEmployee;

public class Employee extends UnicastRemoteObject implements IEmployee {
	private int id;
	private String nom;
	private String prenom;
	private String login; 
	private String mdp;
	private List<String> notifications;
	
	public Employee() throws RemoteException {
		super();
	}
	
	public Employee(int id, String nom, String prenom,String login,String mdp) throws RemoteException {
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.login=login;
		this.mdp=mdp;
		notifications=new ArrayList<String>();
	}

	public void notifyChange(int oldState,int newState,String v_toSting) throws RemoteException {
		notifications.add("STATE:"+oldState+"====>"+newState+" ;Congrats, "+this+ " ,you have rented the car : "+v_toSting+"!!!!!");
		} 

	@Override
	public String toString() {
		return "Employee [id=" + id + ", nom=" + nom + ", prenom=" + prenom + "]";
	}
	
	//GETTERS AND SETTERS

	public int getId() throws RemoteException {
		return id;
	}

	public void setId(int id) throws RemoteException{
		this.id = id;
	}
	public String getNom() throws RemoteException{
		return nom;
	}

	public void setNom(String nom) throws RemoteException{
		this.nom = nom;
	}

	public String getPrenom() throws RemoteException{
		return prenom;
	}

	public void setPrenom(String prenom) throws RemoteException{
		this.prenom = prenom;
	}
	
	public List<String> getNotifications() throws RemoteException{
		return notifications;
	}

	public void setNotifications(List<String> notifications) throws RemoteException{
		this.notifications = notifications;
	}

	public String getLogin() throws RemoteException {
		return login;
	}

	public void setLogin(String login) throws RemoteException{
		this.login = login;
	}

	public String getMdp() throws RemoteException{
		return mdp;
	}

	public void setMdp(String mdp) throws RemoteException{
		this.mdp = mdp;
	}
	
	public String getFullName() throws RemoteException{
		return this.nom + " " +this.prenom;
	}
	
	
}
