package eiffelCorp;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;


import com.ifscars.service.IEmployeeService;
import com.ifscars.service.impl.EmployeeService;

public class EiffelCorpServer_Main {
	
	public static final String HOST="rmi://localhost:";
	
	public static void main(String[] args) {
		try{
			LocateRegistry.createRegistry(1010);
			IEmployeeService empService = EmployeeService.GetInstance();
			Naming.rebind("rmi://localhost:1010/EmployeeService",empService);
			System.out.println("Second RMI Server launched...");
		}catch(Exception e){e.printStackTrace();}
	}

}

