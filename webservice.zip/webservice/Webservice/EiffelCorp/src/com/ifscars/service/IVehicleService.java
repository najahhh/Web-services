package com.ifscars.service;

import java.rmi.Remote;      
import java.rmi.RemoteException;
import java.util.List;

public interface IVehicleService extends Remote {
	public void addVehicle(int mat,String brand,String model,int state,int price) throws RemoteException;
	public void removeVehicleByMatricule(int mat) throws RemoteException;
	public List<IVehicle> getVehicles() throws RemoteException;
	public List<IVehicle> getVehiclesRentedOnce() throws RemoteException;
	public List<IVehicle> getVehiclesForRental() throws RemoteException;
	public List<IVehicle> getVehiclesSOLD() throws RemoteException;
	public void rentVehicle(IEmployee e,IVehicle v) throws RemoteException;
	public void returnVehicle (IVehicle v,String note) throws RemoteException;
	public List<IVehicle> searchByBrand(String brand) throws RemoteException;
	public List<IVehicle> searchByModel(String model) throws RemoteException;
	public IVehicle searchByMatricule(int matricule) throws RemoteException;
	public void buyVehicle(IVehicle v) throws RemoteException;
}
