package com.ifscars.service.impl;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.List;

import com.ifscars.service.IEmployee;
import com.ifscars.service.IEmployeeService;
import com.ifscars.service.IVehicleService;
import eiffelCorp.Employee;



public class EmployeeService extends UnicastRemoteObject implements IEmployeeService {
	
	private List<Employee> EmployeeList;
	
	
	
	 // private constructor restricted to this class itself 
		private EmployeeService() throws RemoteException
	    {
			EmployeeList = new ArrayList<Employee>();
	    }
	     
	    private static EmployeeService single_instance=null; 
	    
	  
	    // static method to create instance of EmployeeService class 
	    public static EmployeeService GetInstance() throws RemoteException
	    { 
	        // To ensure only one instance is created 
	        if (single_instance == null) 
	        { 
	            single_instance = new EmployeeService(); 
	        } 
	        return single_instance; 
	    }
	    
	    //METHODS

		public IEmployee addEmployee(int id,String nom, String prenom,String login, String mdp) throws RemoteException {
			Employee emp = new Employee(id,nom,prenom,login,mdp);
			EmployeeList.add(emp);
			return(emp);
		}

		public void removeEmployeeByID(int id) throws RemoteException {
			for (IEmployee x:EmployeeList) {
				if (x.getId()==id) {
					EmployeeList.remove(x);
				}
			}
		}
		
		public IEmployee getEmployeeByLogins(String login,String mdp) throws RemoteException {
			for (Employee x:EmployeeList) {
				if( (x.getLogin().equals(login)) & (x.getMdp().equals(mdp)) ) {
					return x;
				}
			}
			return null; 
		}
		
		public IEmployee getEmployeeByID(int id) throws RemoteException{
			for (Employee x:EmployeeList) {
				if(x.getId()==id) {
					return x;
				}
			}
			return null;
		}

		public List<IEmployee> getEmployeeList() throws RemoteException {
			List vList=new ArrayList<Employee>();
			for (Employee x:EmployeeList) {
				vList.add(x);
			}
			return(vList);
		}

		
}
