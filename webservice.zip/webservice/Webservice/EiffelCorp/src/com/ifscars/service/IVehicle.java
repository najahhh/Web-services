package com.ifscars.service;

import java.rmi.Remote; 
import java.rmi.RemoteException;
import java.util.List;
import java.util.Queue;

public interface IVehicle extends Remote {
	public int getMatricule() throws RemoteException;
	public void setMatricule(int matricule) throws RemoteException;
	public String getBrand() throws RemoteException;
	public void setBrand(String brand) throws RemoteException;
	public String getModel() throws RemoteException;
	public void setModel(String model) throws RemoteException;
	public int getState() throws RemoteException;
	public void setState(int state) throws RemoteException;
	public double getPrice() throws RemoteException;
	public void setPrice(double price) throws RemoteException;
	public Queue<IEmployee> getSubscribers() throws RemoteException;
	public void setSubscribers(Queue<IEmployee> subscribers) throws RemoteException;
	public int getCounter() throws RemoteException;
	public void setCounter(int counter) throws RemoteException;
	public int getRentedTo_id() throws RemoteException;
	public void setRentedTo_id(int rentedTo_id) throws RemoteException;
	public List<String> getNotes() throws RemoteException;
	public void setNotes(List<String> notes) throws RemoteException;
	public String getRentedTo_fullName() throws RemoteException;
	public void setRentedTo_fullName(String rentedTo_fullName) throws RemoteException;
}
