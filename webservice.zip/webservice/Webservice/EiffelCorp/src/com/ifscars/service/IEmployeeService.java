package com.ifscars.service;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;


public interface IEmployeeService extends Remote  {
	public IEmployee addEmployee(int id,String nom, String prenom,String login, String mdp) throws RemoteException;
	public void removeEmployeeByID(int id) throws RemoteException;
	public IEmployee getEmployeeByLogins(String login,String mdp) throws RemoteException;
	public IEmployee getEmployeeByID(int id) throws RemoteException;
	public List<IEmployee> getEmployeeList() throws RemoteException;
}
